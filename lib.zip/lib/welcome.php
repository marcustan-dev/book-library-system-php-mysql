<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<style>
body{ background:url(images/bg.gif); margin:0; padding:0;}
.header{ background:#3B5998;
height:100px;
width:100%;}
.logo{ margin:auto; margin-top:20px;}
.s:hover{ box-shadow:0px 0px 9px grey; -moz-border-radius:25px;}
</style>
<body>

<div class="logo">
<center><img src="images/sma.png" height="300"width="583" /></center>

</div>
<table align="center" width="500" border="0" style="margin-top:10px;">
<tr><td>
<a href="login.php">
<img src="icons/admin.png" class="s" height="150" />
</a>
</td>
<td align="right">
<a href="stmaryshighschoollibrary.php">
<img src="icons/user.png" class="s" height="150"  />
</a>
</td>
</tr>
</table>
</body>
</html>