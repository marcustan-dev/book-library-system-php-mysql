
<script type="text/javascript">
var auto_refresh = setInterval(
function ()
{
$('#aas').load('load_res.php').fadeIn("slow");
}, 1000); // refresh every 10000 milliseconds

</script>
<div id="aas"></div>
