<?php
 if(isset($_GET['print'])){ 

echo $_POST['checkbox'];

 
 }
 ?>