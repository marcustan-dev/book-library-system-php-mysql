
<div id="hotel">
    <div class="menu">
        <ul>
            
            <li>
                <a href="#"><span class="img"><img src="images/borrowbook.png"width='20px'  height='18px' style=" padding-top:3px;"></span>&nbsp;Books<span class="arrow"></span></a>
                <ul>
                    <li><a href="?">Search Books</a></li>
                    <li><a href="?findBooks">View All Books</a></li>

                </ul>
 </li>
    </div>
    <div id='inlineBox' class='popup_block'>
			<div id='inlineBoxAjax'></div>
		</div>
  