<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<style>
body{
	background:url(images/bg.gif);}
.bgadmin{
	border-radius:10px;
	height:412px;
	margin:auto;
	z-index:1;
	width:426px;}
	.a{
		border:1px #666 solid;
		border-radius:20px;
		margin-top:20px;
		box-shadow:0px 0px 10px grey;
	height:500px;
	width:700px;
	margin:auto;
}
.icons{
	position:absolute; margin-top:-152px; height:200px; width:700px;}
	.left{ float:left;height:200px; width:300px;}
	.right{ float:right; height:200px; width:300px;}
	
.logohalf{ background:url(icons/half.png);
height:412px; width:210px; position:absolute; margin-top:30px;}
</style>
<body>
<br/>

<div class="a">
<div class="logohalf"></div>
<br/>
<div class="bgadmin"></div>
<div class="icons">
<div class="left"><img src="icons/admin.png" height="200" width="200" style="float:right;" /></div>
<div class="right"><img src="icons/user.png" height="200" width="200" style="float:left;" /></div>
</div>
</div>



</body>
</html>